package filters;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.DispatcherType;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

/**
 * Servlet Filter implementation class AuthenticateFilter
 */
@WebFilter(
		dispatcherTypes = {DispatcherType.REQUEST }
					, 
		urlPatterns = { 
				"/AuthenticateFilter", 
				"/*"
		})
public class AuthenticateFilter implements Filter {

    /**
     * Default constructor. 
     */
    public AuthenticateFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpServletRequest req=(HttpServletRequest) request;
		String url = req.getRequestURI();
		System.out.println(url);
		String path=url.substring(url.lastIndexOf("/")+1);
		System.out.println(path);
		if(path.equals("jag") || path.equals("JagServlet"))
		{
			//do authentication
			if(request.getParameter("uid")==null)
			{
				out.println("You have to login first. Click<a href=login.jsp> here </a>to go to login page");
				return;
			}
			String uid=request.getParameter("uid");
			String pwd=request.getParameter("pwd");
			if(uid.equals("rama") && pwd.equals("ravi"))
			{
				chain.doFilter(request, response);
				return;
			}
			else
			{
				out.print("Login failed. Click<a href=login.jsp> here </a>to login again");
				return;
			}
		}
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
